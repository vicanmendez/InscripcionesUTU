
package connectionBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class connectionBD {
    
    
    private static final String URL = "jdbc:mysql://localhost:3306/utu?useSSL=false";
    private static final String USER = "root";
     private static final String PASS = "1234";
     
    public static Connection getConnection() {
        Connection con = null;
          try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL,USER,PASS);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(connectionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
          return con;
    }
}
